package unluac.decompile;

public interface OutputProvider {

  public void print(String s);
  
  public void println();
  
}
