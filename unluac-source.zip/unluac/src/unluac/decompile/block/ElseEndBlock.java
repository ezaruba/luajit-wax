package unluac.decompile.block;

import java.util.ArrayList;
import java.util.List;

import unluac.decompile.Output;
import unluac.decompile.statement.Statement;

public class ElseEndBlock extends Block {

  private final List<Statement> statements;
  public IfThenElseBlock partner;
  
  public ElseEndBlock(int begin, int end) {
    super(begin, end);
    statements = new ArrayList<Statement>(end - begin + 1);
  }
    
  @Override
  public int compareTo(Block block) {
    if(block == partner) {
      return 1;
    } else {
      int result = super.compareTo(block);
      if(result == 0 && block instanceof ElseEndBlock) {
        System.out.println("HEY HEY HEY");
      }
      return result;
    }
  }  
  
  @Override
  public boolean breakable() {
    return false;
  }
  
  @Override
  public boolean isContainer() {
    return true;
  }
  
  @Override
  public void addStatement(Statement statement) {
    statements.add(statement);
  }
  
  @Override
  public boolean isUnprotected() {
    return false;
  }
  
  @Override
  public int getLoopback() {
    throw new IllegalStateException();
  }
  
  @Override
  public void print(Output out) {    
    if(statements.size() == 1 && statements.get(0) instanceof IfThenEndBlock) {
      out.print("else");
      statements.get(0).print(out);
    } else if(statements.size() == 2 && statements.get(0) instanceof IfThenElseBlock && statements.get(1) instanceof ElseEndBlock) {
      out.print("else");
      statements.get(0).print(out);
      statements.get(1).print(out);
    } else {
      out.print("else");
      out.println();
      out.indent();
      Statement.printSequence(out, statements);
      out.dedent();
      out.print("end");
    }
  }
  
}