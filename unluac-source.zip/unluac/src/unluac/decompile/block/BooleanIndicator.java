package unluac.decompile.block;

import unluac.decompile.Output;
import unluac.decompile.statement.Statement;

public class BooleanIndicator extends Block {

  public BooleanIndicator(int line) {
    super(line, line);
  }

  @Override
  public void addStatement(Statement statement) {
    
  }

  @Override
  public boolean isContainer() {
    return false;
  }
  
  @Override
  public boolean isUnprotected() {
    return false;
  }

  @Override
  public boolean breakable() {
    return false;
  }
  
  @Override
  public int getLoopback() {
    throw new IllegalStateException();
  }

  @Override
  public void print(Output out) {
    out.print("-- unhandled boolean indicator");
  }
  
}
