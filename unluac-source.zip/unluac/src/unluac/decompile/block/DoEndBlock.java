package unluac.decompile.block;

import java.util.ArrayList;
import java.util.List;

import unluac.decompile.Output;
import unluac.decompile.statement.Statement;

public class DoEndBlock extends Block {

  private final List<Statement> statements;
  
  public DoEndBlock(int begin, int end) {
    super(begin, end);
    statements = new ArrayList<Statement>(end - begin + 1);
  }

  @Override
  public void addStatement(Statement statement) {
    statements.add(statement);
  }
  
  @Override
  public boolean breakable() {
    return false;
  }
  
  @Override
  public boolean isContainer() {
    return true;
  }
  
  @Override
  public boolean isUnprotected() {
    return false;
  }
  
  @Override
  public int getLoopback() {
    throw new IllegalStateException();
  }
  
  @Override
  public void print(Output out) {
    out.println("do");
    out.indent();
    Statement.printSequence(out, statements);
    out.dedent();
    out.print("end");
  }
  
}
