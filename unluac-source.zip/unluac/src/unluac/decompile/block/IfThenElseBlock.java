package unluac.decompile.block;

import java.util.ArrayList;
import java.util.List;

import unluac.decompile.Output;
import unluac.decompile.Registers;
import unluac.decompile.branch.Branch;
import unluac.decompile.statement.Statement;

public class IfThenElseBlock extends Block {

  private final Branch branch;
  private final int loopback;
  private final Registers r;
  private final List<Statement> statements;
  public ElseEndBlock partner;
  
  public IfThenElseBlock(Branch branch, int loopback, Registers r) {
    super(branch.begin, branch.end);
    this.branch = branch;
    this.loopback = loopback;
    this.r = r;
    statements = new ArrayList<Statement>(branch.end - branch.begin + 1);
  }
  
  @Override
  public int compareTo(Block block) {
    if(block == partner) {
      return -1;
    } else {
      return super.compareTo(block);
    }
  }  
  
  @Override
  public boolean breakable() {
    return false;
  }
  
  @Override
  public boolean isContainer() {
    return true;
  }
  
  @Override
  public void addStatement(Statement statement) {
    statements.add(statement);
  }
  
  @Override
  public boolean isUnprotected() {
    return true;
  }
  
  @Override
  public int getLoopback() {
    return loopback;
  }
  
  @Override
  public void print(Output out) {
    out.print("if ");
    branch.asExpression(r).print(out);
    out.print(" then");
    out.println();
    out.indent();
    //Handle the case where the "then" is empty in if-then-else.
    //The jump over the else block is falsely detected as a break.
    if(statements.size() == 1 && statements.get(0) instanceof Break) {
      Break b = (Break) statements.get(0);
      if(b.target == loopback) {
        out.dedent();
        return;
      }
    }
    Statement.printSequence(out, statements);
    out.dedent();
  }
  
}
