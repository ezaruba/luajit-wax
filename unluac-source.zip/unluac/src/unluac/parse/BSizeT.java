package unluac.parse;

public class BSizeT extends BInteger {
  
  public BSizeT(int n) {
    super(n);
  }
  
}
