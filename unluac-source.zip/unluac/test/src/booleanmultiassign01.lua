local a, b
a, b = a and b, a or b
a, b = a or b, a and b
a, b = b and a, b or a
a, b = b or a, b and a
a, b = x and y, x or y
