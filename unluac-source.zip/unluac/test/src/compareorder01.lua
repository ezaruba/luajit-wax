if a < b then
  print("a < b")
end
if b > a then
  print("b > a")
end
