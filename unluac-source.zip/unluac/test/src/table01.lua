local x
x = {}
x.first = 1
x.second = 2
x.third = 3
y = {first = 1,
     second = 2,
     third = 3}
