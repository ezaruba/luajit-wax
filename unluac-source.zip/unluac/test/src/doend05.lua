repeat
  local v, w = 0
  print(w, v)
until x < 100
