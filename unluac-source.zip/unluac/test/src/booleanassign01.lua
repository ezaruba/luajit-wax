local a
a = x or y
a = x and y
