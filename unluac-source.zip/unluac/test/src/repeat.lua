repeat
  f()
until a
repeat
  if b then
    f()
  end
until a
repeat
  repeat
    f()
  until b
  g()
until a
repeat
  f()
  repeat
    g()
  until b
until a
