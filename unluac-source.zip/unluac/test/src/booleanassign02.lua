local a
a = w and x and y and z
a = w or x or y or z
a = w and x or y and z
a = (w or x) and (y or z)
a = (b and c or d and e) and (f and g or h and i) or (j and k or l and m) and (n and o or p and q)
