if a == b and c == d then
  f()
end
if a == b or c == d then
  f()
end
if a < b then
  f()
end
if a <= b then
  f()
end
if not a then
  f()
end
