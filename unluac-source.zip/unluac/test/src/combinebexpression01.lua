local a
a = b < c or d < e or f
