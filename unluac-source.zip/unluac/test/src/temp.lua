while a do
  if b then
    f()
  end
end
