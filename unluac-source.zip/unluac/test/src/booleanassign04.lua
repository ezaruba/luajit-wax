x = a and b
x = a or b
x = a and b and c and d
x = a or b or c or d
