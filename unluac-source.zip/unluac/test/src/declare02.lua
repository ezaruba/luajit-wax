print("begin")
local x, y, z
print("begin")
local a, b, c
c = 4
print(c)
local d, e, f
d = 8
print(d)