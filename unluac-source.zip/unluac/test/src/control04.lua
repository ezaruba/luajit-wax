local y
if x then
  while y do
	print("hello")
  end
end
