print(x == y)
print(x < y)
print(x <= y)
