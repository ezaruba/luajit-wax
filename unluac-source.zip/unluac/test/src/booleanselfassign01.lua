local a
a = a or x
a = a and x
y = y or x
y = y and x
