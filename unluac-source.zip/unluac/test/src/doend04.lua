for z=1,6 do
  local v, w = 0
  print(w, v, z)
end