if buffer then
  print("hello")
end
local expr1 = a + b + c + d
local expr2 = expr1 + a + b + c + d
local expr3 = a + b + c + d + expr2
