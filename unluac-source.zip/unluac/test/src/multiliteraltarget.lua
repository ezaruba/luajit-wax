local a
a = {f()}
