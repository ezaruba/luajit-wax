function class:method(x)
  self:other_method(x)
end