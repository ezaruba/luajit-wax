local a
a = 5
a = 2.5
a = "hello"
a = false
a = true
a = nil
