print("begin")
if not (math.random(100) > chance) then
  print("then")
end
print("end")