local value = thing.a or thing.b or "default"
print(value)