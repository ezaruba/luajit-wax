if not thing.a and not thing.b then
  side_effects()
  local value = "default"
end