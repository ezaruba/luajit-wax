if x and y then
  f()
  if z then
    g()
  end
end
if x and y then
  if z then
    g()
  end
  f()
end
if x then
  f()
  if y then
    if z then
      g()
    end
    h()
  end
end
